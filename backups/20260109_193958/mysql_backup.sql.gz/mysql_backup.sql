-- MySQL dump 10.13  Distrib 8.4.5, for Linux (aarch64)
--
-- Host: localhost    Database: speed-knowledge
-- ------------------------------------------------------
-- Server version	8.4.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('2eba7055c978');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `file_name` varchar(255) DEFAULT NULL COMMENT '附件名称',
  `file_type` varchar(20) DEFAULT NULL COMMENT '附件类型',
  `object_name` varchar(255) NOT NULL COMMENT '文件的唯一标识路径',
  `file_size` bigint DEFAULT NULL COMMENT '附件大小',
  `bucket_name` varchar(255) NOT NULL COMMENT 'bucket名',
  `user_id` int NOT NULL COMMENT '上传者',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `ix_attachment_file_name` (`file_name`),
  KEY `ix_attachment_id` (`id`),
  KEY `ix_attachment_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
INSERT INTO `attachment` VALUES ('0567a480-0f34-4ab8-9e5d-6ab99dfcd191','default_cover.png','image/png','2/e7527ac1-418b-4a9c-84b8-12333096c1c8_default_cover.png',3962,'speed-knowledge',2,'2025-11-19 18:45:52','2025-11-19 18:45:52'),('1068a1cc-1a1c-4e63-87a9-109c214e0916','default_cover.png','image/png','2/01f90544-19ee-4d8f-99e7-7d3f74b0cce1_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 18:30:22','2025-11-21 18:30:22'),('270c312f-f8f4-496b-b2b5-4974333beb0a','default_cover.png','image/png','2/40f02c42-5817-4d30-af5a-d63ca05ef2ad_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 18:42:20','2025-11-21 18:42:20'),('2c675f90-9891-4ae3-997e-6c3df558c4cc','default_cover.png','image/png','2/6ded7c31-2be6-444a-b4fe-a76ada7f8137_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 18:51:56','2025-11-21 18:51:56'),('37be7f05-431b-4f4f-a15c-756531fb887d','default_cover.png','image/png','2/b0691942-f14e-4103-a609-bf12e118cbe9_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 18:13:06','2025-11-21 18:13:06'),('3b684737-8d18-42f5-9f6e-5628023c06de','default_cover.png','image/png','2/aaf43e7d-53cf-43ac-baa7-6956a6ed5a43_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 18:40:32','2025-11-21 18:40:32'),('53e43f41-8480-46b9-a2be-652269ad1499','default_cover.png','image/png','2/6d27197f-9038-4f98-bedd-e42aec2e8842_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 18:25:07','2025-11-21 18:25:07'),('7a8e847a-30c4-4820-8ad4-26011b4d85a2','A_IvwES5EwvsEAAAAAAAAAAABkARQnAQ.png','image/png','2/f5127dbb-8eb3-4ed6-95f3-4ce2067ba3fc_A_IvwES5EwvsEAAAAAAAAAAABkARQnAQ.png',3962,'speed-knowledge',2,'2025-11-19 18:36:45','2025-11-19 18:36:45'),('c8120f07-4cc1-463e-9119-eface352cd82','default_cover.png','image/png','2/20df2ccd-d338-4cc8-8ad4-e919b19a27a8_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 18:46:27','2025-11-21 18:46:27'),('d1fa32b7-8730-44a4-806e-e509dce13829','default_cover.png','image/png','2/dda33992-aa13-4517-a37c-fa5cb91c89d0_default_cover.png',3962,'speed-knowledge',2,'2025-11-21 17:57:13','2025-11-21 17:57:13');
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collect`
--

DROP TABLE IF EXISTS `collect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collect` (
  `id` varchar(36) NOT NULL,
  `user_id` int NOT NULL COMMENT '用户ID',
  `resource_type` varchar(20) NOT NULL COMMENT '资源类型',
  `knowledge_id` varchar(36) DEFAULT NULL COMMENT '知识库ID',
  `document_id` varchar(36) DEFAULT NULL COMMENT '文档ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_user_knowledge_document` (`user_id`,`knowledge_id`,`document_id`),
  KEY `ix_collect_document_id` (`document_id`),
  KEY `ix_collect_knowledge_id` (`knowledge_id`),
  KEY `ix_collect_user_id` (`user_id`),
  CONSTRAINT `collect_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `document_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `collect_ibfk_2` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `collect_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collect`
--

LOCK TABLES `collect` WRITE;
/*!40000 ALTER TABLE `collect` DISABLE KEYS */;
/*!40000 ALTER TABLE `collect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_base`
--

DROP TABLE IF EXISTS `document_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_base` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `user_id` int NOT NULL COMMENT '所属用户',
  `knowledge_id` varchar(36) NOT NULL COMMENT '所属知识库',
  `name` varchar(128) NOT NULL COMMENT '文档名称',
  `slug` varchar(64) NOT NULL COMMENT '文档短链',
  `type` varchar(10) NOT NULL COMMENT '文档类型',
  `is_public` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否公开',
  `content_updated_at` datetime DEFAULT NULL COMMENT '内容最近更新时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `view_count` int NOT NULL COMMENT '浏览次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_knowledge_id_document_slug` (`knowledge_id`,`slug`),
  KEY `ix_document_base_id` (`id`),
  KEY `ix_document_base_knowledge_id` (`knowledge_id`),
  KEY `ix_document_base_user_id` (`user_id`),
  CONSTRAINT `document_base_ibfk_1` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge_base` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_base`
--

LOCK TABLES `document_base` WRITE;
/*!40000 ALTER TABLE `document_base` DISABLE KEYS */;
INSERT INTO `document_base` VALUES ('29e43e53-179c-4340-bca7-204e17000858',2,'26156ca3-602e-451f-a0d4-141259997aed','无标题文档11','hFRGi4k4CSsBcF20','word',0,'2026-01-09 19:13:25','2026-01-09 19:01:27','2026-01-09 19:13:24',1),('67f61a75-64fa-438a-a3a0-b33f0866ff8a',2,'26156ca3-602e-451f-a0d4-141259997aed','ykx测试文档122333','OAqWnfE0syyDzgUG','word',0,'2026-01-09 17:54:16','2025-12-06 17:00:39','2026-01-09 17:54:16',2);
/*!40000 ALTER TABLE `document_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_content`
--

DROP TABLE IF EXISTS `document_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_content` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `document_id` varchar(36) NOT NULL COMMENT '所属文档',
  `content` blob NOT NULL COMMENT '文档内容(为协同编辑的的二进制数据)',
  `content_updated_at` datetime DEFAULT NULL COMMENT '内容最近更新时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `node_json` text NOT NULL COMMENT '文档内容(为协同编辑的的二进制json数据)',
  PRIMARY KEY (`id`),
  KEY `ix_document_content_document_id` (`document_id`),
  KEY `ix_document_content_id` (`id`),
  CONSTRAINT `document_content_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `document_base` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_content`
--

LOCK TABLES `document_content` WRITE;
/*!40000 ALTER TABLE `document_content` DISABLE KEYS */;
INSERT INTO `document_content` VALUES ('d51bada4-25d5-4115-b166-d44129288369','29e43e53-179c-4340-bca7-204e17000858',_binary '\�͕�\0defaulttitle\0\�͕�\0\0\�͕�无标题文档�Ѻ�\0�\�͕�11��\�\�\0��ޖ\����\�\�我来���\�\����\�\�测试���\�\�\r���\�\�下�ޖ\�\0�\�͕�\0	paragraph(\0�ޖ\�\0indent}\0\0�ޖ\�\0\0�ޖ\�121212��Ľ\0���\�\����Ľ	呃呃呃��\�\�\0��Ľ\0','2026-01-09 19:13:25','2026-01-09 19:01:27','2026-01-09 19:13:24','{\"default\":{\"type\":\"doc\",\"content\":[{\"type\":\"title\",\"content\":[{\"type\":\"text\",\"text\":\"无标题文档11\"}]},{\"type\":\"paragraph\",\"attrs\":{\"indent\":0},\"content\":[{\"type\":\"text\",\"text\":\"121212我来测试下呃呃呃\"}]}]}}'),('f9a31723-3370-4eef-83c5-fd00f97957b7','67f61a75-64fa-438a-a3a0-b33f0866ff8a',_binary '�\�\�\�\0defaulttitle\0�\�\�\�\0\0��\�\�\�\0	paragraph(\0�\�\�\�indent}\0\0\0�\�\�\�\0\"\nށ\�\�\0\0	G�\�\�\�\nemoji(\0ށ\�\�	namewwave\�ށ\�\�	�\�\�\�\n\0ށ\�\�bold{}�ށ\�\�欢迎来到知识库�ށ\�\�boldnullDށ\�\� ��\�\�\�	paragraph(\0ށ\�\�indent}\0����\0A�\��\�\0\0�\��\�\0A\�\�ݜ\0\0�\�\�\0A�\�\��\0\0\�\�ݜ\0A�\�\�\0\0	ק��\0�\���222����\0����\�555\����	\0A����\0\0\n�\��\�\0A�\��\�\0\0�\�\��\0A�\�\�\�\0\���\0���ߠ333��\�\�\0��\�\�\n333��ߠ\0����Y?22���\�\0�ק��44�\�\�\0G\��ۗ\0\0�\�\�\0ykx测试文档122\��ۗ\0A\����	\0\0ʖ��\0�����666�淘\0\0ށ\�\�\0�淘\0)\n���Y\0��淘)����Y我����Y����Y$可以����Y&\n����Y0加点����Y2����Y9东西����Y;����Y=吗？�\�\�\�(ށ\�\�\0	����\0�\��\�\0�\�\�\0\�\�ݜ\0\n\����	\0�\��\�\0�\�\��\0\��ۗ\0	�淘)���Y\0\'\n3<','2026-01-09 17:54:16','2025-12-06 17:00:39','2026-01-09 17:54:16','{\"default\":{\"type\":\"doc\",\"content\":[{\"type\":\"title\",\"content\":[{\"type\":\"text\",\"text\":\"ykx测试文档122333\"}]},{\"type\":\"paragraph\",\"attrs\":{\"indent\":0},\"content\":[{\"type\":\"emoji\",\"attrs\":{\"name\":\"wave\"}},{\"type\":\"text\",\"text\":\" \"},{\"type\":\"text\",\"text\":\"欢迎来到知识库\",\"marks\":[{\"type\":\"bold\",\"attrs\":{}}]}]},{\"type\":\"paragraph\",\"attrs\":{\"indent\":0},\"content\":[{\"type\":\"text\",\"text\":\"我可以加点东西吗？2233322244555666\"}]}]}}');
/*!40000 ALTER TABLE `document_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_node`
--

DROP TABLE IF EXISTS `document_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_node` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `type` varchar(10) NOT NULL COMMENT '节点类型',
  `title` varchar(128) NOT NULL COMMENT '节点标题',
  `parent_id` varchar(36) DEFAULT NULL COMMENT '父节点ID',
  `first_child_id` varchar(36) DEFAULT NULL COMMENT '第一个子节点ID',
  `document_id` varchar(36) DEFAULT NULL COMMENT '所属文档ID',
  `prev_id` varchar(36) DEFAULT NULL COMMENT '前一个节点ID',
  `next_id` varchar(36) DEFAULT NULL COMMENT '下一个节点ID',
  `knowledge_id` varchar(36) DEFAULT NULL COMMENT '所属知识库ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `ix_document_node_document_id` (`document_id`),
  KEY `ix_document_node_first_child_id` (`first_child_id`),
  KEY `ix_document_node_id` (`id`),
  KEY `ix_document_node_knowledge_id` (`knowledge_id`),
  KEY `ix_document_node_next_id` (`next_id`),
  KEY `ix_document_node_parent_id` (`parent_id`),
  KEY `ix_document_node_prev_id` (`prev_id`),
  CONSTRAINT `document_node_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `document_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_node_ibfk_2` FOREIGN KEY (`first_child_id`) REFERENCES `document_node` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_node_ibfk_3` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_node_ibfk_4` FOREIGN KEY (`next_id`) REFERENCES `document_node` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_node_ibfk_5` FOREIGN KEY (`parent_id`) REFERENCES `document_node` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_node_ibfk_6` FOREIGN KEY (`prev_id`) REFERENCES `document_node` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_node`
--

LOCK TABLES `document_node` WRITE;
/*!40000 ALTER TABLE `document_node` DISABLE KEYS */;
INSERT INTO `document_node` VALUES ('2b6108bd-5259-401d-9728-578e19128014','DOC','ykx测试文档122333',NULL,NULL,'67f61a75-64fa-438a-a3a0-b33f0866ff8a',NULL,NULL,'26156ca3-602e-451f-a0d4-141259997aed','2025-12-06 17:00:39','2025-12-06 17:00:39'),('c53024c1-ba75-4a18-a6d9-6c9d5d832288','DOC','无标题文档11',NULL,NULL,'29e43e53-179c-4340-bca7-204e17000858',NULL,'2b6108bd-5259-401d-9728-578e19128014','26156ca3-602e-451f-a0d4-141259997aed','2026-01-09 19:01:37','2026-01-09 19:01:37');
/*!40000 ALTER TABLE `document_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base`
--

DROP TABLE IF EXISTS `knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `user_id` int NOT NULL COMMENT '所属用户',
  `name` varchar(128) NOT NULL COMMENT '知识库名称',
  `slug` varchar(64) NOT NULL COMMENT '知识库短链',
  `description` varchar(512) DEFAULT NULL COMMENT '简介',
  `cover_url` json DEFAULT NULL COMMENT '封面图信息',
  `is_public` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否公开',
  `content_updated_at` datetime DEFAULT NULL COMMENT '内容最近更新时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `group_id` varchar(36) NOT NULL COMMENT '所属分组',
  `icon` varchar(20) NOT NULL COMMENT '知识库图标',
  `enable_catalog` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用目录',
  `layout` varchar(20) NOT NULL COMMENT '布局',
  `sort` varchar(20) NOT NULL COMMENT '排序',
  `enable_custom_body` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否启用自定义模块',
  `enable_user_feed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否显示协同人员',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_knowledge_slug` (`slug`),
  KEY `ix_knowledge_base_group_id` (`group_id`),
  KEY `ix_knowledge_base_id` (`id`),
  KEY `ix_knowledge_base_user_id` (`user_id`),
  CONSTRAINT `knowledge_base_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `knowledge_group` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base`
--

LOCK TABLES `knowledge_base` WRITE;
/*!40000 ALTER TABLE `knowledge_base` DISABLE KEYS */;
INSERT INTO `knowledge_base` VALUES ('26156ca3-602e-451f-a0d4-141259997aed',2,'ykx测试知识库1','4onWfw','啊啊','{\"id\": \"0567a480-0f34-4ab8-9e5d-6ab99dfcd191\", \"fileName\": \"default_cover.png\", \"fileSize\": 3962, \"fileType\": \"image/png\"}',0,NULL,'2025-11-21 20:08:31','2026-01-09 15:05:24','5c75553f-2f64-4b48-a55a-9736b8d6c746','icon-book-0',1,'catalog','catalog',0,0),('98b18a48-eee0-4888-806c-9a90bf49ac89',2,'ykx测试知识库2','Zn8m5T','不错额','{\"id\": \"0567a480-0f34-4ab8-9e5d-6ab99dfcd191\", \"fileName\": \"default_cover.png\", \"fileSize\": 3962, \"fileType\": \"image/png\"}',0,NULL,'2025-11-21 20:26:38','2026-01-09 15:05:24','5c75553f-2f64-4b48-a55a-9736b8d6c746','icon-book-3',1,'catalog','catalog',0,0),('eaf6c137-ad56-4784-80f8-0f5c968467bd',2,'ykx测试知识库3','PXUTKW','不不不','{\"id\": \"0567a480-0f34-4ab8-9e5d-6ab99dfcd191\", \"fileName\": \"default_cover.png\", \"fileSize\": 3962, \"fileType\": \"image/png\"}',0,NULL,'2025-11-21 20:33:59','2026-01-09 15:05:24','5c75553f-2f64-4b48-a55a-9736b8d6c746','icon-book-9',1,'catalog','catalog',0,0);
/*!40000 ALTER TABLE `knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_collaborator`
--

DROP TABLE IF EXISTS `knowledge_collaborator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_collaborator` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `knowledge_id` varchar(36) NOT NULL COMMENT '所属知识库',
  `user_id` int NOT NULL COMMENT '所属用户',
  `role` int NOT NULL COMMENT '角色',
  `status` int NOT NULL COMMENT '状态',
  `source` int NOT NULL COMMENT '来源',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `ix_knowledge_collaborator_id` (`id`),
  KEY `ix_knowledge_collaborator_knowledge_id` (`knowledge_id`),
  KEY `ix_knowledge_collaborator_user_id` (`user_id`),
  CONSTRAINT `knowledge_collaborator_ibfk_1` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `knowledge_collaborator_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_collaborator`
--

LOCK TABLES `knowledge_collaborator` WRITE;
/*!40000 ALTER TABLE `knowledge_collaborator` DISABLE KEYS */;
INSERT INTO `knowledge_collaborator` VALUES ('12c1d95f-1691-4d59-8176-20534b56558d','26156ca3-602e-451f-a0d4-141259997aed',2,3,2,0,'2026-01-04 17:37:01','2026-01-04 17:37:01'),('70560ce7-5562-45eb-81ce-9f1ddb8d5ecb','26156ca3-602e-451f-a0d4-141259997aed',4,1,2,1,'2026-01-06 15:35:52','2026-01-06 15:35:52'),('af81bed1-49f4-4449-b220-ea0b1902623c','26156ca3-602e-451f-a0d4-141259997aed',3,1,2,1,'2026-01-05 15:58:12','2026-01-05 15:58:12');
/*!40000 ALTER TABLE `knowledge_collaborator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_daily_stats`
--

DROP TABLE IF EXISTS `knowledge_daily_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_daily_stats` (
  `id` varchar(36) NOT NULL,
  `knowledge_id` varchar(36) NOT NULL,
  `stats_date` date NOT NULL,
  `word_count` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_knowledge_id_stats_date` (`knowledge_id`,`stats_date`),
  KEY `idx_knowledge_id` (`knowledge_id`),
  KEY `idx_stats_date` (`stats_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_daily_stats`
--

LOCK TABLES `knowledge_daily_stats` WRITE;
/*!40000 ALTER TABLE `knowledge_daily_stats` DISABLE KEYS */;
INSERT INTO `knowledge_daily_stats` VALUES ('2a7d1860-7647-4f9c-a0b5-150bec1ef820','26156ca3-602e-451f-a0d4-141259997aed','2026-01-08',12,'2026-01-08 17:59:00','2026-01-08 17:59:00'),('7203e05b-7ff6-4712-97fe-6f921ed236cc','eaf6c137-ad56-4784-80f8-0f5c968467bd','2026-01-08',12,'2026-01-08 17:59:00','2026-01-08 17:59:00'),('8085ac99-b1cd-482e-8e9f-0a858bf1d3dd','98b18a48-eee0-4888-806c-9a90bf49ac89','2026-01-08',12,'2026-01-08 17:59:00','2026-01-08 17:59:00');
/*!40000 ALTER TABLE `knowledge_daily_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_group`
--

DROP TABLE IF EXISTS `knowledge_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_group` (
  `id` varchar(36) NOT NULL COMMENT '分组ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `group_name` varchar(255) DEFAULT NULL COMMENT '分组名称',
  `order_index` int DEFAULT '0' COMMENT '排序索引',
  `is_default` tinyint(1) DEFAULT NULL COMMENT '是否默认分组',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `display_config` json DEFAULT NULL COMMENT '显示配置',
  PRIMARY KEY (`id`),
  KEY `ix_knowledge_group_group_name` (`group_name`),
  KEY `ix_knowledge_group_id` (`id`),
  KEY `ix_knowledge_group_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_group`
--

LOCK TABLES `knowledge_group` WRITE;
/*!40000 ALTER TABLE `knowledge_group` DISABLE KEYS */;
INSERT INTO `knowledge_group` VALUES ('06458191-389f-4412-9c7a-8273b61d045a',4,'我的知识库',0,1,'2026-01-06 15:35:35','2026-01-06 15:35:35','{\"type\": \"card\", \"style\": \"detail\", \"doc_order_type\": 1, \"show_knowledge_icon\": true, \"show_knowledge_description\": true}'),('30ae65c3-7e12-4640-9ee4-2ecd73fac02c',1,'我的知识库',0,1,'2026-01-04 19:29:16','2026-01-04 19:29:16','{\"type\": \"card\", \"style\": \"detail\", \"doc_order_type\": 1, \"show_knowledge_icon\": true, \"show_knowledge_description\": true}'),('513eabf6-c748-4c6b-9ec1-15ff701a3faa',3,'我的知识库',0,1,'2026-01-04 20:00:14','2026-01-04 20:00:14','{\"type\": \"card\", \"style\": \"detail\", \"doc_order_type\": 1, \"show_knowledge_icon\": true, \"show_knowledge_description\": true}'),('51df5499-93ac-4843-aaf5-2bc0223ceec2',3,'我的知识库',0,1,'2025-12-16 17:44:45','2025-12-16 17:44:45','{\"type\": \"card\", \"style\": \"detail\", \"doc_order_type\": 1, \"show_knowledge_icon\": true, \"show_knowledge_description\": true}'),('5c75553f-2f64-4b48-a55a-9736b8d6c746',2,'我的知识库',0,1,'2025-11-19 11:49:57','2025-11-19 11:49:57','{\"type\": \"card\", \"style\": \"detail\", \"doc_order_type\": 1, \"show_knowledge_icon\": true, \"show_knowledge_description\": true}');
/*!40000 ALTER TABLE `knowledge_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_invitation`
--

DROP TABLE IF EXISTS `knowledge_invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_invitation` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `knowledge_id` varchar(36) NOT NULL COMMENT '所属知识库',
  `inviter_id` int DEFAULT NULL COMMENT '被邀请用户id',
  `token` varchar(45) NOT NULL COMMENT '邀请链接token',
  `role` int NOT NULL COMMENT '角色',
  `need_approval` int DEFAULT NULL COMMENT '是否需要审批:0-否,1-是',
  `status` int NOT NULL COMMENT '状态:1-正常,2-已撤销',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `ix_knowledge_invitation_id` (`id`),
  KEY `ix_knowledge_invitation_inviter_id` (`inviter_id`),
  KEY `ix_knowledge_invitation_knowledge_id` (`knowledge_id`),
  CONSTRAINT `knowledge_invitation_ibfk_1` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge_base` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_invitation`
--

LOCK TABLES `knowledge_invitation` WRITE;
/*!40000 ALTER TABLE `knowledge_invitation` DISABLE KEYS */;
INSERT INTO `knowledge_invitation` VALUES ('02ed06aa-fb78-43dd-879d-fa22ab739f94','26156ca3-602e-451f-a0d4-141259997aed',2,'mn21oUDH6pceMCBK',1,1,1,'2025-12-21 19:04:04','2025-12-21 19:04:04');
/*!40000 ALTER TABLE `knowledge_invitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_user_email` (`email`),
  UNIQUE KEY `ix_user_username` (`username`),
  KEY `ix_user_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'15982819091@163.com','ykx_test1','$2b$12$zCo2HWSPAT.gD/LMCheYEOaFZhcqqotIiZd09hvvmYs8qhwRmshou','游开兴测试1','2026-01-04 19:29:16','2026-01-04 19:29:16'),(3,'1358645278@qq.com','ykx_test2','$2b$12$vN4Tb4LoMiRKa6isaaMU0u8DYm5Dr/V1UylDUB.gKucqWzIC4HYz2','游开兴测试2','2026-01-04 20:00:14','2026-01-04 20:00:14'),(4,'1392227049@qq.com','123','$2b$12$L1dBfmzlNSbf/SQg9cxeFet8FiRUuT.TOrc6dOQrv2zZMt19yExb.','123','2026-01-06 15:35:35','2026-01-06 15:35:35');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'speed-knowledge'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-09 11:39:58
